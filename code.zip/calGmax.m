function gg=calGmax(max_nfes,max_pop_size,min_pop_size)
    gg=0;
    nfes=max_pop_size;
    pop_size=max_pop_size;
    while nfes < max_nfes
        gg=gg+1;
        nfes=nfes+pop_size;
        plan_pop_size = round((((min_pop_size - max_pop_size) / max_nfes) * nfes) + max_pop_size);
        pop_size=plan_pop_size;
    end
end