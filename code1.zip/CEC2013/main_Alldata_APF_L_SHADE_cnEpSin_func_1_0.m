rng('default')
clear all
close all
%%
StrAlgorithm=['All_Data_APF_L_SHADE_cnEpSin_func_'];
%% 范围和问题
VRmin=-100;
VRmax=100;
tempfile=[];
noPro0=1:28;
%% 重复试验次数
repNum=1;
optimum_objs2=zeros(repNum,length(noPro0));
%% 生成随机数种子 (并行计算专用，其他方法在并行时无法保证结果复现)
% Generate random number seeds (for parallel computation, ensures result reproducibility)
rng('default')
mainSeed = 1;
% 创建一个随机数流对象 (Create a random number stream object)
stream = RandStream('mt19937ar', 'Seed', mainSeed);
seeds = cell(1, repNum);
for i = 1:repNum
    seeds{i} = RandStream('mt19937ar', 'Seed', mainSeed + i);
end
%%
problemSet=[];
for no=1:28
    for D=100
       problemSet=[problemSet;no,D];
    end
end
%% 实验参数
% delete(gcp('nocreate'));
% parpool(8);

result1=[];
%%
paramemter=[
    10,10,0,0;
    ];
numP=length(paramemter(:,1)); %参数组合数量
R_obj{numP}=[];
R_T{numP}=[];
for k=1:numP
    if isempty(R_obj{k})
        optimum_objs=[];
        runningTime=[];
        for ii=1:length(problemSet(:,1))
            noPro=problemSet(ii,1);
            Dimension=problemSet(ii,2);
            tempfile=[noPro,paramemter(k,:)];
            parfor j=1:repNum
                % 获取当前迭代的随机数流 (Get the current iteration's random number stream)
                currentStream = seeds{j};
                % 设置当前工作者的随机数流 (Set the current worker's random number stream)
                RandStream.setGlobalStream(currentStream);
                tic;
                [~,optimum_objs0(j,ii),~] = func_APF_L_SHADE_cnEpSin_90(Dimension,VRmin,VRmax,tempfile);
                runningTime0(j,ii)=toc;
                disp(['Par:',num2str(k),'-Pro:',num2str(ii),'-Rep:',num2str(j),'-Obj:',num2str(optimum_objs0(j,ii))])
            end
            disp(num2str(mean(optimum_objs0(:,ii))));
            disp(num2str(mean(runningTime0(:,ii))));
            optimum_objs=optimum_objs0;
            runningTime=runningTime0;
         end
    end
    R_obj{k}=optimum_objs;
    R_T{k}=runningTime;
    meanT(k,:)=mean(runningTime);
    meanObj(k,:)=mean(optimum_objs);
end
disp(StrAlgorithm)
%%
R.meanT=meanT;
R.meanObj=meanObj;
R.R_obj=R_obj;
R.R_T=R_T;
R.parameters=paramemter;
str=['CECE2020-',StrAlgorithm];
save([str,date],'R')
