function [y,x]=funcEval(x,noPro)
    %global noPro
    %x=x';
    [f, g, h] =cec20_func(x,noPro);
    g = max(g, 0);
    h = abs(h);
    g(g<1e-4)=0;
    h(h<1e-4)=0;
    temp=[g;h];
    temp=sum(temp);
    y=f'+1000*temp;
    y=y';
end